#!/bin/bash
set -e -x
javac Game.java View.java Controller.java
