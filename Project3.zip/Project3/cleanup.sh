rm -f *.swp
rm -f *.swn
rm -f *.swo
rm -f *.class
rm -f .*.swp
rm -f .*.swo
